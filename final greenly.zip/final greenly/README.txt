# How to Run Greenly (Without XAMPP)

We have updated the project to run cleanly on a standard PHP installation using SQLite, so you don't need the heavy XAMPP/MySQL setup.

## Prerequisites
1. **Install PHP**:
   - Download **VS16 x64 Non Thread Safe** (or Thread Safe) zip from [windows.php.net](https://windows.php.net/download/).
   - Extract the zip to a folder, e.g., `C:\php`.
   - **Crucial**: Add `C:\php` to your Windows **Environment Variables > Path**.
   - **Enable Extensions**:
     - Rename `php.ini-development` to `php.ini`.
     - Open `php.ini` and remove the `;` from the start of these lines:
       - `extension=pdo_sqlite`
       - `extension=sqlite3`
       - `extension=fileinfo` (optional but good)

## One-Click Start
1. Double-click the `run_project.bat` file in this folder.
2. It will:
   - Check if PHP is installed.
   - Create the database (`greenly.sqlite`) automatically.
   - Start the local server.
   - Open your browser to the site.

## Manual Start
If you prefer the command line:
1. Open Terminal/Command Prompt in this folder.
2. Run database setup: `php setup_sqlite.php`
3. Start server: `php -S localhost:8000`
4. Go to `http://localhost:8000`

## Features & Credentials
- **Admin**: No default admin. Register a user, then open `greenly.sqlite` (using a tool like *DB Browser for SQLite*) and change their role to `admin`.
- **Gardeners**: Dummy data included. Register a new gardener to test login.
