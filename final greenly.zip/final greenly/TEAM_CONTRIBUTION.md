# 🌿 GREENLY - Team Contribution & Project Documentation

## 📋 Project Overview
**Project Name:** Greenly - Plant Shop & Gardening Services Platform  
**Technology Stack:** PHP, SQLite, HTML, CSS, JavaScript  
**Team Size:** 3 Members

---

# 👥 TEAM MEMBERS & FILE ALLOCATION

---

## 👤 MEMBER 1: Frontend Developer (UI/UX Design)
**Name:** ________________________________  
**Role:** Frontend Developer & UI/UX Designer

### 📂 Files Created/Managed:

| S.No | File Name | Location | Description |
|------|-----------|----------|-------------|
| 1 | `style.css` | assets/css/ | Main stylesheet with 1000+ lines - colors, animations, responsive design |
| 2 | `main.js` | assets/js/ | JavaScript - theme toggle, mobile menu, interactions |
| 3 | `header.php` | includes/ | Navigation bar, logo, user menu, mobile menu |
| 4 | `footer.php` | includes/ | Footer with links, contact info, social icons |
| 5 | `index.php` | root | Homepage - hero section, categories, trending products |
| 6 | `contact.php` | root | Contact us page with form and map |
| 7 | `blogs.php` | root | Blog listing page |
| 8 | All images | assets/images/ | 17 product images (plants, pots, tools, fertilizers) |

### 🎨 Key Contributions:
- Designed complete website UI with green theme
- Created animated hero section with floating elements
- Implemented dark/light mode toggle
- Made responsive design for mobile devices
- Designed product cards with hover effects
- Created glassmorphism effects and modern styling

### 📝 Presentation Points:
1. "Maine pure website ka visual design kiya hai"
2. "CSS mein 1000+ lines of styling likhi hai"
3. "Responsive design banaya - mobile, tablet, desktop sab pe kaam karta hai"
4. "Dark mode aur light mode toggle feature add kiya"
5. "Modern animations aur hover effects implement kiye"
6. "All product images manage kiye assets folder mein"

---

## 👤 MEMBER 2: Backend Developer (Database & Authentication)
**Name:** ________________________________  
**Role:** Backend Developer & Database Administrator

### 📂 Files Created/Managed:

| S.No | File Name | Location | Description |
|------|-----------|----------|-------------|
| 1 | `db.php` | includes/ | Database connection with PDO |
| 2 | `setup_sqlite.php` | root | Database schema - all tables creation |
| 3 | `database.sql` | root | SQL schema documentation |
| 4 | `greenly.sqlite` | root | SQLite database file |
| 5 | `login.php` | root | User login with session management |
| 6 | `register.php` | root | User registration with password hashing |
| 7 | `logout.php` | root | Session destroy and logout |
| 8 | `add_to_cart_action.php` | root | Cart add/remove operations |
| 9 | `add_to_wishlist.php` | root | Wishlist add functionality |
| 10 | `place_order_action.php` | root | Order placement logic |
| 11 | `book_service.php` | root | Service booking logic |
| 12 | `add_dummy_data.php` | root | Seed data for testing |

### 🗄️ Database Tables Created:
1. `users` - Customer accounts
2. `gardeners` - Gardener profiles
3. `categories` - Product categories
4. `products` - Product catalog
5. `cart` - Shopping cart
6. `wishlist` - User wishlists
7. `orders` - Order records
8. `order_items` - Order details
9. `services` - Service bookings
10. `feedback` - Customer reviews

### 📝 Presentation Points:
1. "Maine database design kiya hai SQLite use karke"
2. "10 database tables create kiye user, products, orders ke liye"
3. "Secure authentication system banaya - password hashing ke saath"
4. "Session management implement kiya for user login"
5. "Cart aur wishlist functionality PHP mein likhi"
6. "Order processing logic create kiya"

---

## 👤 MEMBER 3: Feature Developer (E-commerce & Services)
**Name:** ________________________________  
**Role:** Full Stack Developer - Features & Integration

### 📂 Files Created/Managed:

| S.No | File Name | Location | Description |
|------|-----------|----------|-------------|
| 1 | `shop.php` | root | Product listing with filters, search, sorting |
| 2 | `product_details.php` | root | Individual product page |
| 3 | `cart.php` | root | Shopping cart display |
| 4 | `checkout.php` | root | Checkout process |
| 5 | `order_confirmation.php` | root | Order success page |
| 6 | `services.php` | root | Gardening services listing |
| 7 | `dashboard.php` | root | User dashboard with orders & bookings |
| 8 | `my_orders.php` | root | Order history with cancel/delete/invoice |
| 9 | `my_bookings.php` | root | Service bookings with feedback system |
| 10 | `invoice.php` | root | Printable invoice generation |
| 11 | `wishlist.php` | root | Wishlist page |
| 12 | `feedback.php` | root | Customer feedback handling |
| 13 | `gardener_dashboard.php` | root | Gardener panel |
| 14 | `admin/dashboard.php` | admin/ | Admin panel |

### 🛒 Key Features Implemented:
1. **Shop System** - Product browsing, filtering, search
2. **Cart System** - Add, remove, quantity management
3. **Order System** - Checkout, order tracking, order history
4. **Invoice System** - Professional PDF-style invoices
5. **Booking System** - Gardener service booking
6. **Dashboard** - User account management
7. **Feedback System** - Star rating & reviews

### 📝 Presentation Points:
1. "Maine complete e-commerce module banaya"
2. "Shop page mein filtering, sorting, search features add kiye"
3. "Cart se checkout tak poora flow implement kiya"
4. "Invoice generation feature banaya - printable invoices"
5. "Gardener booking system create kiya"
6. "User dashboard banaya orders aur bookings manage karne ke liye"

---

# 📊 PROJECT FILE SUMMARY

## Total Files: 41

| Category | Count | Owner |
|----------|-------|-------|
| Frontend (CSS/JS/Design) | 8 | Member 1 |
| Backend (DB/Auth/Logic) | 12 | Member 2 |
| Features (Shop/Orders/Services) | 14 | Member 3 |
| Utility/Helper Scripts | 7 | Shared |

---

# 🎤 PRESENTATION SCRIPT

## 1. Introduction (2 min)
```
"Aaj hum present kar rahe hain GREENLY - ek online plant shop 
aur gardening services platform. Is project mein users plants 
kharid sakte hain aur gardeners book kar sakte hain."
```

## 2. Technology Stack (1 min)
```
"Humne use kiya hai:
- PHP for backend logic
- SQLite for database
- HTML/CSS for frontend
- JavaScript for interactivity"
```

## 3. Live Demo (10 min)

### Demo Flow:
1. **Homepage Tour** (Member 1)
   - Hero section
   - Categories
   - Trending products
   - Dark mode toggle

2. **Shop & Cart** (Member 3)
   - Browse products
   - Filter by category
   - Add to cart
   - Checkout process

3. **User Account** (Member 2)
   - Register new account
   - Login
   - Dashboard
   - Order history

4. **Service Booking** (Member 3)
   - View gardeners
   - Book service
   - View booking
   - Give feedback

5. **Invoice** (Member 3)
   - View order
   - Generate invoice
   - Print invoice

## 4. Database Explanation (2 min) - Member 2
```
"Database mein 10 tables hain:
- users, gardeners for accounts
- products, categories for catalog
- orders, order_items for purchases
- services for bookings
- wishlist, cart, feedback for features"
```

## 5. Code Architecture (2 min)
```
"Project structure:
- includes/ folder mein reusable components
- assets/ folder mein CSS, JS, images
- Root mein main PHP pages
- SQLite database file"
```

## 6. Conclusion (1 min)
```
"Is project mein humne complete e-commerce solution 
banaya hai jo real-world plant business ke liye 
use ho sakta hai. Thank you!"
```

---

# 📁 COMPLETE FILE LIST BY MEMBER

## Member 1 - Frontend (8 files)
```
✅ assets/css/style.css
✅ assets/js/main.js  
✅ includes/header.php
✅ includes/footer.php
✅ index.php
✅ contact.php
✅ blogs.php
✅ assets/images/ (17 images)
```

## Member 2 - Backend (12 files)
```
✅ includes/db.php
✅ setup_sqlite.php
✅ database.sql
✅ greenly.sqlite
✅ login.php
✅ register.php
✅ logout.php
✅ add_to_cart_action.php
✅ add_to_wishlist.php
✅ place_order_action.php
✅ book_service.php
✅ add_dummy_data.php
```

## Member 3 - Features (14 files)
```
✅ shop.php
✅ product_details.php
✅ cart.php
✅ checkout.php
✅ order_confirmation.php
✅ services.php
✅ dashboard.php
✅ my_orders.php
✅ my_bookings.php
✅ invoice.php
✅ wishlist.php
✅ feedback.php
✅ gardener_dashboard.php
✅ admin/dashboard.php
```

## Shared/Utility (7 files - Not for presentation)
```
⚙️ ai_scan.php
⚙️ check_tables.php
⚙️ create_test_user.php
⚙️ debug_login.php
⚙️ fix_all_images.php
⚙️ update_*.php
⚙️ verify_db.php
```

---

# ✅ VIVA QUESTIONS & ANSWERS

### Q1: What technology did you use?
**A:** PHP for backend, SQLite for database, HTML/CSS/JS for frontend

### Q2: Why SQLite instead of MySQL?
**A:** SQLite is lightweight, no server setup needed, portable, perfect for small projects

### Q3: How did you implement authentication?
**A:** Using PHP sessions, password_hash() for secure password storage, password_verify() for login

### Q4: How does the cart work?
**A:** Cart data stored in PHP SESSION array, synced with database when user logs in

### Q5: How many database tables are there?
**A:** 10 tables - users, gardeners, categories, products, cart, wishlist, orders, order_items, services, feedback

### Q6: Is the website responsive?
**A:** Yes, CSS media queries used for mobile, tablet, and desktop views

### Q7: How do you generate invoices?
**A:** PHP generates HTML invoice page, CSS @media print for print styling

### Q8: How did you divide the work?
**A:** Frontend/Design (Member 1), Backend/Database (Member 2), Features/Integration (Member 3)

---

**Document Created:** December 18, 2024  
**Project:** Greenly - Plant Shop & Gardening Services
