<?php
session_start();
// Since admin is in subfolder, paths need adjustment for includes
// We can use ../ to step out, or just copy/include directly.
// To avoid path hell, let's keep it simple: relative paths.
// But wait, the previous files were in root.
// If I put this in admin/dashboard.php, I need to include ../includes/db.php
// And ../includes/header.php might have links like "index.php" which would break if not absolute.
// "index.php" becomes "admin/index.php" which doesn't exist.
// Solution: Use absolute paths in header or base tag. Or copy header for admin.
// I'll create a simple admin specific header in the file itself to save time/complexity.

include '../includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Handle Gardener Assignment
if(isset($_POST['assign_gardener'])) {
    $service_id = $_POST['service_id'];
    $gardener_id = $_POST['gardener_id'];
    
    $stmt = $pdo->prepare("UPDATE services SET gardener_id = :gid, service_status = 'pending' WHERE service_id = :sid");
    $stmt->bindParam(':gid', $gardener_id);
    $stmt->bindParam(':sid', $service_id);
    $stmt->execute();
    $msg = "Gardener assigned successfully.";
}

// Handle Add Product (Simple)
if(isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category_id = $_POST['category_id'];
    $stock = $_POST['stock'];
    $description = $_POST['description'];
    
    // Image Upload (Simple)
    $image = '';
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0){
        $target_dir = "../uploads/";
        $filename = time() . "_" . basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $filename;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image = $filename;
        }
    }
    
    $stmt = $pdo->prepare("INSERT INTO products (name, category_id, price, description, image, stock) VALUES (:name, :cat, :price, :desc, :img, :stock)");
    $stmt->execute([':name'=>$name, ':cat'=>$category_id, ':price'=>$price, ':desc'=>$description, ':img'=>$image, ':stock'=>$stock]);
    $msg = "Product added successfully.";
}

// Fetch Data
$services = $pdo->query("SELECT s.*, u.name as user_name FROM services s JOIN users u ON s.user_id = u.user_id WHERE s.gardener_id IS NULL")->fetchAll();
$gardeners = $pdo->query("SELECT * FROM gardeners WHERE status = 'available'")->fetchAll();
$all_orders = $pdo->query("SELECT count(*) as count, sum(total_amount) as revenue FROM orders")->fetch();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Greenly</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { padding-top: 0; background-color: #f4f6f8; }
        .admin-sidebar { width: 250px; height: 100vh; background: #2e7d32; color: white; position: fixed; left: 0; top: 0; padding: 20px; }
        .admin-content { margin-left: 250px; padding: 40px; }
        .admin-sidebar a { display: block; color: white; padding: 15px; text-decoration: none; border-radius: 5px; margin-bottom: 5px; }
        .admin-sidebar a:hover { background: rgba(255,255,255,0.1); }
        .card-stat { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

<div class="admin-sidebar">
    <h2 style="margin-bottom: 40px;">Greenly Admin</h2>
    <a href="#" class="active"><i class="fa-solid fa-gauge"></i> Dashboard</a>
    <a href="../index.php" target="_blank"><i class="fa-solid fa-home"></i> View Site</a>
    <a href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
</div>

<div class="admin-content">
    <h1>Dashboard Overview</h1>
    
    <div class="grid-sidebar" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 40px;">
        <div class="card-stat">
            <h3 style="color: #666;">Total Orders</h3>
            <p style="font-size: 2rem; font-weight: bold;"><?php echo $all_orders['count']; ?></p>
        </div>
        <div class="card-stat">
            <h3 style="color: #666;">Total Revenue</h3>
            <p style="font-size: 2rem; font-weight: bold; color: green;">₹<?php echo number_format($all_orders['revenue'], 2); ?></p>
        </div>
        <div class="card-stat">
            <h3 style="color: #666;">Pending Services</h3>
            <p style="font-size: 2rem; font-weight: bold; color: orange;"><?php echo count($services); ?></p>
        </div>
    </div>

    <!-- Pending Services Assignment -->
    <div style="background: white; padding: 30px; border-radius: 10px; margin-bottom: 40px;">
        <h2>Unassigned Service Requests</h2>
        <?php if(isset($msg)) echo "<p style='color: green;'>$msg</p>"; ?>
        
        <?php if(count($services) > 0): ?>
            <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                <tr style="text-align: left; border-bottom: 2px solid #eee;">
                    <th>ID</th>
                    <th>Customer</th>
                    <th>Service</th>
                    <th>Date</th>
                    <th>Assign To</th>
                    <th>Action</th>
                </tr>
                <?php foreach($services as $svc): ?>
                    <tr style="border-bottom: 1px solid #eee;">
                        <td style="padding: 10px;">#<?php echo $svc['service_id']; ?></td>
                        <td><?php echo htmlspecialchars($svc['user_name']); ?></td>
                        <td><?php echo ucfirst($svc['service_type']); ?></td>
                        <td><?php echo $svc['service_date']; ?></td>
                        <form method="post">
                            <input type="hidden" name="service_id" value="<?php echo $svc['service_id']; ?>">
                            <td>
                                <select name="gardener_id" required style="padding: 8px;">
                                    <option value="">Select Gardener</option>
                                    <?php foreach($gardeners as $g): ?>
                                        <option value="<?php echo $g['gardener_id']; ?>"><?php echo htmlspecialchars($g['name']); ?> (<?php echo $g['rating']; ?>★)</option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <button type="submit" name="assign_gardener" class="btn btn-primary" style="padding: 8px 15px; font-size: 0.8rem;">Assign</button>
                            </td>
                        </form>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p>No pending services.</p>
        <?php endif; ?>
    </div>

    <!-- Add Product -->
    <div style="background: white; padding: 30px; border-radius: 10px;">
        <h2>Add New Product</h2>
        <form method="post" enctype="multipart/form-data" style="margin-top: 20px; max-width: 600px;">
            <div class="form-group">
                <label>Product Name</label>
                <input type="text" name="name" required style="width: 100%; padding: 10px; margin-bottom: 10px;">
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category_id" style="width: 100%; padding: 10px; margin-bottom: 10px;">
                    <option value="1">Plants</option>
                    <option value="2">Pots</option>
                    <option value="3">Fertilizers</option>
                    <option value="4">Tools</option>
                </select>
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="number" step="0.01" name="price" required style="width: 100%; padding: 10px; margin-bottom: 10px;">
            </div>
            <div class="form-group">
                <label>Stock</label>
                <input type="number" name="stock" required style="width: 100%; padding: 10px; margin-bottom: 10px;">
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" rows="3" style="width: 100%; padding: 10px; margin-bottom: 10px;"></textarea>
            </div>
            <div class="form-group">
                <label>Image</label>
                <input type="file" name="image" style="margin-bottom: 20px;">
            </div>
            <button type="submit" name="add_product" class="btn btn-primary">Add Product</button>
        </form>
    </div>

</div>

</body>
</html>
