<?php
include 'includes/db.php';
include 'includes/header.php';

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role']; // Register as Customer or Gardener

    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "Please fill in all fields.";
    } elseif ($password != $confirm_password) {
        $error = "Passwords did not match.";
    } else {
        // Check if email exists
        $table = ($role === 'gardener') ? 'gardeners' : 'users';
        $sql_check = "SELECT email FROM $table WHERE email = :email";
        
        if($stmt = $pdo->prepare($sql_check)){
            $stmt->bindParam(":email", $email, PDO::PARAM_STR);
            if($stmt->execute()){
                if($stmt->rowCount() > 0){
                    $error = "This email is already taken.";
                } else {
                    // Insert new user
                    $sql_insert = "";
                    if ($role === 'gardener') {
                        $sql_insert = "INSERT INTO gardeners (name, email, password, status) VALUES (:name, :email, :password, 'available')";
                    } else {
                        // Default to customer, admin is manual
                        $sql_insert = "INSERT INTO users (name, email, password, role) VALUES (:name, :email, :password, 'customer')";
                    }

                    if($stmt_insert = $pdo->prepare($sql_insert)){
                        $stmt_insert->bindParam(":name", $name, PDO::PARAM_STR);
                        $stmt_insert->bindParam(":email", $email, PDO::PARAM_STR);
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $stmt_insert->bindParam(":password", $hashed_password, PDO::PARAM_STR);

                        if($stmt_insert->execute()){
                            $success = "Registration successful! You can now login.";
                        } else {
                            $error = "Something went wrong. Please try again.";
                        }
                    }
                }
            }
        }
    }
}
?>

<div class="auth-container">
    <div class="auth-box">
        <h2>Join Greenly</h2>
        <?php if($error): ?>
            <div style="color: red; margin-bottom: 10px;"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if($success): ?>
            <div style="color: green; margin-bottom: 10px;"><?php echo $success; ?> <a href="login.php">Login here</a></div>
        <?php endif; ?>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" required>
            </div>
            <div class="form-group">
                <label>Register As</label>
                <select name="role">
                    <option value="customer">Customer</option>
                    <option value="gardener">Gardener</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%;">Register</button>
        </form>
        <div class="auth-link">
            Already have an account? <a href="login.php">Login</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
