<?php
// DB Connection - switched to SQLite for standalone ease
$db_file = __DIR__ . '/../greenly.sqlite';

try {
    $pdo = new PDO("sqlite:$db_file"); // Use SQLite
    // $pdo = new PDO("mysql:host=localhost;dbname=greenly_db", "root", ""); // Old MySQL
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Enable Foreign Keys for SQLite
    $pdo->exec("PRAGMA foreign_keys = ON;");
    
} catch(PDOException $e) {
    // If SQLite fails, maybe guide user to run setup
    die("Connection failed: " . $e->getMessage() . " <br>If using SQLite, make sure to run 'php setup_sqlite.php' first.");
}
?>
