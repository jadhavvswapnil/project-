</div> <!-- End main-content -->

<footer class="footer">
    <div class="container footer-container">
        <div class="footer-col">
            <h3>Greenly 🌱</h3>
            <p>Your one-stop solution for all gardening needs. From plants to expert gardeners, we have it all.</p>
            <div class="social-links">
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
            </div>
        </div>
        
        <div class="footer-col">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h4>Support</h4>
            <ul>
                <li><a href="#">FAQ</a></li>
                <li><a href="#">Shipping Policy</a></li>
                <li><a href="#">Returns</a></li>
                <li><a href="#">Terms & Conditions</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h4>Contact</h4>
            <p><i class="fa-solid fa-location-dot"></i> 123 CILIV LINE , NAGPUR 440016</p>
            <p><i class="fa-solid fa-phone"></i> +91 72491 64457</p>
            <p><i class="fa-solid fa-envelope"></i> help@greenly.com</p>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2025 Greenly. All rights reserved.</p>
    </div>
</footer>

<script src="assets/js/main.js"></script>
</body>
</html>
